# Rixz Hosting — VPS & Premium Store

Next.js storefront for Vercel. Includes ARTAN SHOP API v2 QRIS checkout, payment polling + callback verification, automatic VPS provisioning (DigitalOcean / Linode / Pterodactyl), premium-account stock delivery, and a password-protected admin panel.

## 1. Database setup
1. Create a Supabase project.
2. Open **SQL Editor** and run `supabase/schema.sql`.
3. Copy the project URL and **service role** key from Supabase settings. The service-role key is secret and must only be configured server-side.

Supabase is used instead of SQLite because Vercel serverless deployments do not provide durable local-disk storage across invocations.

## 2. Local setup
- Node.js 20.9+
- `cp .env.example .env.local` then fill the values.
- `npm install`
- `npm run dev`

## 3. Required environment variables
Set these in Vercel → Project → Settings → Environment Variables:

- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `ARTAN_API_KEY`
- `ARTAN_BASE_URL=https://tokoshopp.web.id`
- `ADMIN_PASSWORD` (long unique password)
- `ADMIN_SESSION_SECRET` (at least 32 random characters)

Never prefix secrets with `NEXT_PUBLIC_`. ARTAN requests are sent from server routes with `X-API-Version: v2` and `x-api-key`.

## 4. VPS provider setup
Choose/configure only the providers you intend to sell:

### DigitalOcean
Set `DIGITALOCEAN_TOKEN`. The sample plan in `lib/catalog.ts` uses `region=sgp1`, `size=s-1vcpu-2gb`, `image=ubuntu-24-04-x64`. Change the plan values to IDs available in your account. New droplets use cloud-init to set a generated root password. Verify your image's SSH/password policy and security settings before selling.

### Linode
Set `LINODE_TOKEN`. Sample plan uses `region=ap-south`, `type=g6-standard-2`, `image=linode/ubuntu24.04`. The app generates a root password and returns it after instance creation.

### Pterodactyl
Set `PTERODACTYL_URL`, `PTERODACTYL_APPLICATION_KEY`, `PTERODACTYL_EGG_ID`, `PTERODACTYL_LOCATION_ID`; optionally set `PTERODACTYL_NEST_ID`, `PTERODACTYL_DOCKER_IMAGE`, `PTERODACTYL_STARTUP`, and `PTERODACTYL_ENV_JSON` (valid JSON object containing the variables required by your egg). The app creates a panel user then server through the Application API. Ensure the selected egg supports the configured startup/environment and the node has available allocations.

Edit `lib/catalog.ts` to set product names, prices, provider, plan size, region, image, RAM, disk and CPU. Prices are Indonesian Rupiah. VPS plans are charged as one-time 30-day orders; renewal/suspension/deletion automation is not included in this starter.

## 5. Premium stock
1. Deploy and open `/admin`.
2. Login using `ADMIN_PASSWORD`.
3. Add accounts to the correct product. Each stock row is sold/reserved once after payment verification.
4. Customer receives the account data in their checkout result. Add stock before making a premium product available.

Edit `PREMIUM_PRODUCTS` in `lib/catalog.ts` to change product names and prices. Do not put real account data in source files.

## 6. ARTAN webhook
Set the callback URL in ARTAN dashboard to:

`https://YOUR-DOMAIN.vercel.app/api/webhook/payment`

The callback is treated as a notification only. The server independently calls ARTAN `/api/payment/status` before marking an order paid. The checkout page also polls status, so it can still update if the callback is delayed.

## 7. Deploy to Vercel
1. Push this project to a private GitHub repository.
2. Import it in Vercel.
3. Add environment variables listed above.
4. Deploy. Framework preset: Next.js; build command: `npm run build`.
5. Configure the ARTAN callback URL after deployment.

### If the deployed URL shows 404
- In Vercel → Project → Settings → General, set **Root Directory** to `./` (the folder containing `package.json` and `app/`).
- Keep **Framework Preset** set to `Next.js`.
- Leave **Output Directory** empty / use the Next.js default. Do not set it to `public`, `dist`, or `build`.
- Redeploy after saving settings. The project includes `app/page.tsx` as its `/` route and `vercel.json` explicitly selects the Next.js framework.

## Important production checks
- Test each provider with a low-priced internal test product before accepting public orders. Provider API calls may create billable infrastructure.
- A VPS API create response can mean the resource is still provisioning; IP/status may initially be pending. This starter records the create response; add provider polling/status refresh before promising an immediately ready server.
- If provisioning fails after payment, the order is marked `failed` and visible in admin. Admin must resolve/refund manually; do not assume an automatic refund is performed by ARTAN.
- Configure real provider limits, account security, firewall, backups, legal terms, privacy notice, and refund policy before launch.
- Keep all API keys and Supabase service role key private. Rotate them immediately if exposed.

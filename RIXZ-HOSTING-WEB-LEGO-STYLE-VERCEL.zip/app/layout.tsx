import type { Metadata } from "next";
import "./globals.css";
export const metadata:Metadata={title:"Rixz Hosting — VPS & Premium Store",description:"Pesan VPS dan akun premium dengan proses otomatis, pembayaran QRIS, dan layanan 24/7."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="id"><body>{children}</body></html>}

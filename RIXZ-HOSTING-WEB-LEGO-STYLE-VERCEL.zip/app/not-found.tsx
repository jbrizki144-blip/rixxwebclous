import Link from "next/link";

export default function NotFound() {
  return (
    <main className="wrap" style={{ minHeight: "75vh", display: "grid", placeItems: "center" }}>
      <section className="hero" style={{ width: "min(100%, 650px)", textAlign: "center", margin: 0 }}>
        <div className="eyebrow">404 · PAGE NOT FOUND</div>
        <h1 style={{ fontSize: "clamp(42px, 8vw, 64px)" }}>Oops, halaman tidak ditemukan.</h1>
        <p style={{ marginInline: "auto" }}>Halaman yang kamu cari mungkin sudah dipindahkan atau alamatnya salah.</p>
        <Link href="/" className="btn" style={{ display: "inline-block", width: "auto", marginTop: 14 }}>Kembali ke beranda</Link>
      </section>
    </main>
  );
}
